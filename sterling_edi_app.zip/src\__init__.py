"""
IBM Sterling EDI Application
A comprehensive EDI processing toolkit for IBM Sterling B2B Integrator environments.
"""

__version__ = "1.0.0"

